var docdata = {};
